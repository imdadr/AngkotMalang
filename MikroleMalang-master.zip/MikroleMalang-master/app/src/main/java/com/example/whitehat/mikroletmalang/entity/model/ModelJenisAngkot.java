package com.example.whitehat.mikroletmalang.entity.model;

/**
 * Created by whitehat on 04/05/17.
 */

public class ModelJenisAngkot {

    private String imageangkot;
    private String namaAngkot1;
    private String namaAngkot2;

//    public ModelJenisAngkot(int imageangkot, String namaAngkot1, String namaAngkot2) {
//        this.imageangkot = imageangkot;
//        this.namaAngkot1 = namaAngkot1;
//        this.namaAngkot2 = namaAngkot2;
//    }

    public String getImageangkot() {
        return imageangkot;
    }

    public void setImageangkot(String imageangkot) {
        this.imageangkot = imageangkot;
    }

    public String getNamaAngkot1() {
        return namaAngkot1;
    }

    public void setNamaAngkot1(String namaAngkot1) {
        this.namaAngkot1 = namaAngkot1;
    }

    public String getNamaAngkot2() {
        return namaAngkot2;
    }

    public void setNamaAngkot2(String namaAngkot2) {
        this.namaAngkot2 = namaAngkot2;
    }
}
