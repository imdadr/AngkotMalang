package com.example.whitehat.mikroletmalang.support;

/**
 * Created by rofiqoff on 9/26/17.
 */

public class AutocompleteAdapter {
}
